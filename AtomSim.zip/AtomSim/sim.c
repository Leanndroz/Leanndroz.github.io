#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

struct movingPoint {
  int x;
  int y;

  // 0 = top left      
  // 1 = top         000      
  // 2 = top right   0C0       
  // 3 = right       000  
  // etc...
  int dir;

  char matrix[15][40];
};

void updateFrame(struct movingPoint* point) {
  int lastx = point->x;
  int lasty = point->y;
  int lastdir = point->dir;

  time_t t;
  srandom((unsigned) time(&t));
  

  int rand = random();
  //printf("\n%d", rand);
  rand = rand % 3;
  printf("\n%d", rand);
  //rand = rand % 3;

  //point is moving "<-"  
  //                       
  if(lastx == 0 && (lastdir == 0 || lastdir == 6 || lastdir == 7)) {
    //point->x = lastx + 1;

    if(rand == 0) {
      point->dir = 2;
    }
    else if(rand == 1) {
      point->dir = 3;
    }
    else if(rand == 2) {
     point->dir = 4;
    }
  }
  //point is moving "->"
  else if(lastx == 40-1 && (lastdir == 2 || lastdir == 3 || lastdir == 4)) {
    //point->x = lastx - 1;
   
    if(rand == 0) {
      point->dir = 0;
    }
    else if(rand == 1) {
      point->dir = 7;
    }
    else if(rand == 2) {
      point->dir = 6;
    }
  }

  else if(lasty == 15-1 && (lastdir == 4 || lastdir == 5 || lastdir == 6)) {
    //point->y = lasty - 1;
   
    if(rand == 0) {
      point->dir = 0;
    }
    else if(rand == 1) {
      point->dir = 1; 
    }
    else if(rand == 2) {
      point->dir = 2;
    }
  }

  else if(lasty == 0 && (lastdir == 0 || lastdir == 1 || lastdir == 2)) {
    //point->y = lasty + 1;

    if(rand == 0) {
      point->dir = 4;
    }
    else if(rand == 1) {
      point->dir = 5;
    }
    else if(rand == 2) {
      point->dir = 6;
    }
  }
  else {
    if(lastdir == 0) {
      point->x--;
      point->y--;
    }
    else if(lastdir == 1) {
      point->y--;
    }
    else if(lastdir == 2) {
      point->x++;
      point->y--;
    } 
    else if(lastdir == 3) {
      point->x++;
    }
    else if(lastdir == 4) {
     point->x++;
     point->y++;
    }
    else if(lastdir == 5) {
     point->y++;
    }
    else if(lastdir == 6) {
      point->y++;
      point->x--;
    }
    else if(lastdir == 7) {
      point->x--;
    }
    
  }
  //printf("lastx: %d\nlasty: %d\n", lastx, lasty);
  //printf("char: %c", point->matrix[lastx][lasty]);
  point->matrix[lasty][lastx] = '.';

  //printf("char2: %c", point->matrix[lastx][lasty]);
  point->matrix[point->y][point->x] = 'X';
}

int main() {
  int h = 15;
  int l = 40;

  int startx;
  int starty;
  int startdir;
  char startchar;
  
  system("clear");
  printf("Starting X: ");
  scanf("%d", &startx);

  printf("Starting Y: ");
  scanf("%d", &starty);

  printf("Starting Direction: ");
  scanf("%d", &startdir);

  printf("Starting Character: ");
  scanf(" %c", &startchar);
   
  //int startx = 20;
  //int starty = 7;

  struct movingPoint point;
  point.x = startx;
  point.y = starty;
  point.dir = startdir;
 
  //Pointer to struct
  struct movingPoint *ptr_point = &point;


  int g;
  int x;
  for(g=0; g<h; g++) {
    for(x=0; x<l; x++) {
      point.matrix[g][x] = ' ';
    }
  }
 
  //Assign start value
  point.matrix[starty][startx] = startchar;

  system("clear");
  //usleep(500000);
  
  while(1) {
    printf("\n%s\n\n", "ATOM SIMULATION - Isaac L. Kenyon");
    int i;
    int j;   
    for(i=0; i<h; i++) {
      for(j=0; j<l; j++) {
        printf("%c", point.matrix[i][j]);
      }
      printf("%s", "\n");
    }
    printf("%s", "\n");
    //75000
    usleep(25000);

    int oldx = point.x;
    int oldy = point.y;

    //printf("old X: %d\nold Y: %d\n", point.x, point.y);
    //point.matrix[oldx][oldy] = 'a';
    updateFrame(ptr_point);
    
    //printf("new X: %d\nnew Y: %d\n", point.x, point.y);
    //system("clear");
    int newline = 0;
    while(newline < 50) { printf("\n"); newline++; };
  }

  return 0;
}
