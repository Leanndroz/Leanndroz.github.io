import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileWriter;

public class ADT {

    //  The file that contains the text
    private static String file = null;

    //  If tree needs to be loaded rather than created
    private static Boolean loadTree = false;

    //  Name of new tree file to be loaded
    private static String loadTreeName = null;

    //  Type classification enum
    enum Type { ARTICLE, PAPER, TEXT, EMAIL, CONVERSATION, RESEARCH_PAPER }

    //  The type classification of the text being entered
    private static Type type = null;

    //  If word files need to be loaded
    private static Boolean loadWord = false;

    //  Name of word file to be loaded
    private static String loadWordName = null;

    //  Name of top information file
    private static String TopInfo = null;

    public static void main(String[] args)  {

        /* USER INPUT AND FILE SELECTION */

        System.out.println("\nAlgorithmic Text Detection(ADT)\n");

        //  Get the file that contains the text
        Scanner scnr = new Scanner(System.in);
        System.out.print("  File Input: ");
        ADT.file = scnr.nextLine();

        //  Ask user if a tree needs to be loaded
        System.out.print("\n  Load Tree(y/n): ");
        String answer = scnr.nextLine().toLowerCase();
        if(answer.equals("y") || answer.equals("yes")) { ADT.loadTree = true; } else { ADT.loadTree = false; }

        //  Ask user for tree file name if needed
        if(ADT.loadTree == true) { System.out.print("  Name: "); ADT.loadTreeName = scnr.nextLine(); }

        //  Ask user if a word file needs to be loaded
        System.out.print("\n  Load Words(y/n): ");
        answer = scnr.nextLine().toLowerCase();
        if(answer.equals("y") || answer.equals("yes")) { ADT.loadWord = true; } else { ADT.loadWord = false; }

        //  Ask user for word file name if needed
        if(ADT.loadWord == true) { System.out.print("  Name: "); ADT.loadWordName = scnr.nextLine(); }

        //  Get the type of file input from the user
        System.out.print("\n  Type of File Input\n    ARTICLE\n    PAPER\n    TEXT\n    EMAIL\n    CONVERSATION\n    RESEARCH_PAPER\n\n  : ");
        ADT.type = getType(scnr.nextLine());

        //  Get the top information file from user
        System.out.print("\n  Top Information File: ");
        ADT.TopInfo = scnr.nextLine();


        /* READING CONFIGURATION FILES AND BUILDING DATA STRUCTURES */
        TextTree textTree;
        Words words;


        //  Create TextTree that will be used for analysis
        if(ADT.loadTree == true) {
            textTree = new TextTree(ADT.loadTreeName);

            words = new Words();
            words.tokenize(ADT.file);
            words.appendToTree(textTree);

            System.out.println(textTree.checkWord(words, "access-expression,"));

            //System.out.println(textTree.checkWord("test"));

            try { 
                PrintWriter writer = new PrintWriter(new FileWriter("tree.txt"));
                textTree.serialize(textTree.root, writer);
                writer.close();
            } catch(IOException e) { e.printStackTrace(); }  
        }
        else {

            // Create empty TextTree
            textTree = new TextTree();

            // Load words into Words object 
            words = new Words();
            words.tokenize(ADT.file);
            words.appendToTree(textTree);

            words.readInWordObj("counts/tallyout2.txt");
            words.fuzeTokens();
            words.writeWordObjArray("counts/tallyout2.txt");
            System.out.println("Total Words: " + words.getTotalWords());
            words.printWordObjCounts();
            words.printWordObjWord();

            // System.out.print("Enter file for token array: ");
            // String filename = scnr.nextLine();
            // words.writeTokenArray(filename);

            // System.out.print("Enter file to print tally count: ");
            // String outputfile = scnr.nextLine();
            // words.tallyCountsOutput(filename, outputfile);

            try { 
                PrintWriter writer = new PrintWriter(new FileWriter("tree.txt"));
                textTree.serialize(textTree.root, writer);
                writer.close();
            } catch(IOException e) { e.printStackTrace(); }
        }
    }

    private static Type getType(String str) {
        str = str.toLowerCase();
        if(str.equals("article")) { return Type.ARTICLE; }
        else if(str.equals("paper")) { return Type.PAPER; }
        else if(str.equals("text")) { return Type.TEXT; }
        else if(str.equals("email")) { return Type.EMAIL; }
        else if(str.equals("conversation")) { return Type.CONVERSATION; }
        else if(str.equals("research_paper")) { return Type.RESEARCH_PAPER; }
        else { return null; }
    }
}