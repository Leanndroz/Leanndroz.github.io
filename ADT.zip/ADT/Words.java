import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileReader;
import java.util.Stack;
import java.util.ArrayList;
import java.nio.file.Path;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.util.Collections;

public class Words {

    // wordArray will contain all of the known words by this system
    private ArrayList<String> wordArray = new ArrayList<String>();

    // tokenArray contains words that have been read from a text file
    private ArrayList<String> tokenArray = new ArrayList<String>();

    // WordObj array
    private ArrayList<Word> wordObj = new ArrayList<Word>();

    // Words constructor, that takes a '.word' file and saves them into memory for fast access.
    public Words() {
        // Empty constructor for when no words need to be loaded
    }

    // Words constructor, that takes a '.word' file and saves them into memory for fast access.
    public Words(String filename) {
        try {
            File file=new File("Demo.txt");    //creates a new file instance  
            FileReader fr=new FileReader("words/" + filename);   //reads the file  
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream

            String line;
            while((line=br.readLine())!=null) {
                wordArray.add(line);
            }  
            fr.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
        Collections.sort(this.wordArray);
    }

    public int getWordObjLength() {
        return this.wordObj.size();
    }

    public String getWordObjWord(int index) {
        return this.wordObj.get(index).getWord();
    }

    public void readInWordObj(String filename) {
        try {
            File file=new File(filename);    //creates a new file instance  
            FileReader fr=new FileReader(filename);   //reads the file  
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream

            String line = "";
            int tally = 1;
            while((line = br.readLine())!=null) {
                int length = line.length();
                String word = "";


                for(int i=0; i < length; i++) {
                    char c = line.charAt(i);

                    if(c != ' ') {
                        word += c;
                    }
                    else if(c == ' ') {
                        i++;
                        c = line.charAt(i);
                        String number = "";
                        while(i < length) {
                            number += c;
                            c = line.charAt(i);
                            i++;
                            
                        }
                        int count = Integer.parseInt(number);
                        this.wordObj.add(new Word(word, count));

                    }
                }
            }  
            fr.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void printWordObj() {
        for(int i=0; i < this.wordObj.size(); i++) {
            this.wordObj.get(i).printData();
        }
    }

    public void printWordObjCounts() {
        try {
            FileWriter myWriter = new FileWriter("counts.txt");
            for(int i=0; i<this.wordObj.size(); i++) {
                myWriter.write("\n" + this.wordObj.get(i).getCount());
                
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void printWordObjWord() {
        try {
            FileWriter myWriter = new FileWriter("words.txt");
            for(int i=0; i<this.wordObj.size(); i++) {
                myWriter.write("\n" + this.wordObj.get(i).getWord());
                
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public Word checkObjWord(String word) {
        for(int i=0; i < this.wordObj.size(); i++) {
            if(this.wordObj.get(i).getWord().equals(word)) {
                return this.wordObj.get(i);
            }
        }
        return null;
    }

    public int getTotalWords() {
        int total = 0;
        for(int i=0; i < this.wordObj.size(); i++) {
            total += this.wordObj.get(i).getCount();
        }
        return total;
    }

    public void fuzeTokens() {
        for(int i=0; i < this.tokenArray.size(); i++) {
            Word word = checkObjWord(this.tokenArray.get(i));
            if(word != null) {
                word.addCount();
            }
            else if(word == null) {
                this.wordObj.add(new Word(this.tokenArray.get(i), 1));
                //System.out.println("ADDING");
            }
        }
    }

    // tokenize() takes a file as input that contains text to be used to train the system.
    // As of right now it can only tokenize ascii text
    public void tokenize(String filename) {
        // Create file object from given file.
        File file = new File(filename);        
 
        // Attempt to read file.
        try (FileReader fr = new FileReader(file)) {
            int content;
            boolean buildingWord = false;
            String word = "";
            while ((content = fr.read()) != -1) {
                char c = (char)content;
                //System.out.println(c);
                if((c != ' ' && c != '\n' && c != '\t' && c != '\r') && buildingWord == false) {
                    word +=c;
                    buildingWord = true;
                }
                else if((c == ' ' || c == '\n' || c == '\t' || c == '\r') && buildingWord == true) {
                    this.tokenArray.add(word);
                    buildingWord = false;
                    //System.out.println(word);
                    word = "";
                }
                else if(c != ' ' && c != '\n' && c != '\t' && c != '\r'){
                    word += c;
                }
            }
            if(word.length() > 0) {
                this.tokenArray.add(word);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Collections.sort(this.tokenArray);
    }

    public void writeWordObjArray(String filename) {
        try {
            FileWriter myWriter = new FileWriter(filename);
            for(int i=0; i<this.wordObj.size(); i++) {
                myWriter.write(this.wordObj.get(i).getWord() + " " + this.wordObj.get(i).getCount());
                if(i != -1 && i != this.wordObj.size()-1) {
                    myWriter.write("\n");
                }
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void tallyCountsOutput(String filename, String outputfile) {
        try {
            File file=new File(filename);    //creates a new file instance  
            FileReader fr=new FileReader("inputs/" + filename);   //reads the file  
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream

            String lastword = "";
            String newword = "";
            int tally = 1;
            while((newword=br.readLine())!=null) {
                //System.out.println(newword);
                if(newword.equals(lastword)) {
                    tally++;
                    lastword = newword;
                }
                else {
                    try {
                        FileWriter myWriter = new FileWriter("counts/"+outputfile, true);
                        myWriter.write(lastword + " " + tally + "\n");
                        myWriter.close();
                        tally = 1;
                        lastword = newword;
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }
            }  
            fr.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void tallyCounts() {

    }

    public void collectData() {

        

        for(int i=0; i<this.tokenArray.size()-1; i++) {
            if(!new File("words/after/" + this.tokenArray.get(i) + ".word").isFile()) {
                try {
                    FileWriter myWriter = new FileWriter("words/after/"+this.tokenArray.get(i), true);
                    myWriter.write("");
                    myWriter.close();
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }
            if(!new File("words/before/" + this.tokenArray.get(i) + ".word").isFile()) {
                try {
                    FileWriter myWriter = new FileWriter("words/before/"+this.tokenArray.get(i), true);
                    myWriter.write("");
                    myWriter.close();
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }

            
        }
    }

    public void appendToTree(TextTree tree) {
        for(int i=0; i<this.tokenArray.size()-1; i++) {
            tree.appendWord(this.tokenArray.get(i));
        }
    }

    public boolean checkWord(String word) {
        return false;
    }
}