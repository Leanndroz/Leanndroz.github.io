import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileReader;
import java.util.Stack;
import java.util.ArrayList;
import java.nio.file.Path;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;

public class TextTree {

    //  Characters that can appear within the TextTree structure as keys
    private char[] chacters = {'!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', 
                        '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', 
                        ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
                        'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 
                        'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 
                        'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 
                        's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~'};

    // Root Node that will never not have a null key
    public Node root;

    private String output;

    public TextTree() {

        // Add NUL key to root
        this.root = new Node((char)0);
        this.root.parent = null;
    }

    //  TextTree constructor for building tree from file.

    public TextTree(String filename) {

        // Add NUL key to root
        this.root = new Node((char)0);
        this.root.parent = null;

        // Create file object from given file.
        File file = new File(filename);

        // Get the root Node and save in separate variable
        Node node = this.root;
 
        // Attempt to read file.
        try (FileReader fr = new FileReader(file)) {
            int content;
            while ((content = fr.read()) != -1) {
                if((char)content == ' ') {
                    // Navigate back up to the current Nodes parent
                    node = node.parent;
                    //System.out.print(" ");
                }
                else {
                    // Add a child Node to the current Node, then change current Node to that added child 
                    node.addChild((char)content);
                    node = node.getChild((char)content);
                    //System.out.print((char)content);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //System.out.print("\n");
    }

    public String getOutput() {
        return this.output;
    }

    public void saveTree(String filename) throws IOException {

        // // Get the root of the tree as a starting point
        // Node node = this.root;

        String output = "";

        // Create a java stack for preorder traversal
        Stack<Node> stack = new Stack<>();
 
        // 'Preorder'-> contains all the
        // visited nodes
        ArrayList<Character> Preorder = new ArrayList<>();
 
        stack.push(this.root);
 
        int interations = 0;
        while (!stack.isEmpty()) {
            Node temp = stack.peek();
            stack.pop();

            // store the key in preorder vector(visited list)
            Preorder.add(temp.key);

            // Push all of the child nodes of temp into
            // the stack from right to left.
            for (int i = temp.children.size() - 1; i >= 0; i--) {
                stack.push(temp.children.get(i));
                
            }
            if(temp.children.size()-1 == -1) {
                Preorder.add(' ');
            } 
        }
        
        for (char c : Preorder) {
            output += c;
        }
    }

    public void preorderTraversal() {

        // // Get the root of the tree as a starting point
        // Node node = this.root;

        String output = "";

        // Create a java stack for preorder traversal
        Stack<Node> stack = new Stack<>();
 
        // 'Preorder'-> contains all the
        // visited nodes
        ArrayList<Character> Preorder = new ArrayList<>();

        int words = 0;
 
        stack.push(this.root);
 
        int interations = 0;
        while (!stack.isEmpty()) {
            Node temp = stack.peek();
            stack.pop();

            // store the key in preorder vector(visited list)
            Preorder.add(temp.key);

            // Push all of the child nodes of temp into
            // the stack from right to left.
            for (int i = temp.children.size() - 1; i >= 0; i--) {
                stack.push(temp.children.get(i));
                
            }
            if(temp.children.size()-1 == -1) {
                Preorder.add(' ');
                words++;
            } 
        }
        
        for (char c : Preorder) {
            output += c;
        }
        System.out.println(output);
        System.out.println("Number of words: " + words);
    }

    public void serialize(Node root, PrintWriter writer) throws IOException {
        // Base case
        if (root == null) {
            return;
        }
 
        // Else, store current node and recur for its children
        if(root.parent != null) {
            writer.print(root.key);
        }
        
        for (int i = 0; i < root.children.size() && root.children.get(i) != null; i++) {
            serialize(root.children.get(i), writer);
        }
 
        // Store marker at the end of children
        if(root.parent != null) {
            writer.print(" ");
        }
    }

    public void appendWord(String word) {
        int length = word.length();
        Node current = this.root;

        for(int i=0; i<length-1; i++) {
            char c = word.charAt(i);
            if(!current.checkChild(c)) {
                current.addChild(c);
            }
            current = current.getChild(c);
        }
    }

    public boolean checkWord(Words words, String word) {
        for(int i=0; i < words.getWordObjLength(); i++) {
            if(words.getWordObjWord(i).equals(word)) {
                return true;
            }
        }
        return false;
    }


    //  Node class object that holds the parent, key, and children of given Node.
    //  No repeat key values in a Nodes children.
    //  33 is the offset to 0 index, possibly don't define SIZE, and OFFSET because of memory saving reasons!

    private class Node {

        //  The parent of this Node object.  It can only have one parent.
        public Node parent;

        //  The character that this node is associated with.
        public char key;

        // The size of the children array
        private static int SIZE = 94;

        // The array of children spots that holds.
        private Node[] NodeChildren = new Node[Node.SIZE];

        // ArrayList of the children Nodes
        private ArrayList<Node> children = new ArrayList<Node>();

    // Constructor
    private Node(char key) {
        this.key = key;
    }

    private void addChild(char key) {

        // Creat the new child, add to children array, and set parent Node.
        Node child = new Node(key);
        this.children.add(child);
        child.parent = this;
    }

    private boolean checkChild(char key) {

        // Get a integer index for the array of charKeys.
        // Check and return boolean value if child exists
        for(int i=0; i<this.children.size(); i++) {
            if(key == this.children.get(i).key) { return true; } 
        }
        return false;
    }

    private Node getChild(char key) {

        // // Get a integer index for the array of charKeys.
        // // return the Node at that index
        // return this.NodeChildren[((int)key)-33];

        for(int i=0; i < this.children.size(); i++) {
            if(this.children.get(i).key == key) { return this.children.get(i); }
        }
        return null;
    }
}
}