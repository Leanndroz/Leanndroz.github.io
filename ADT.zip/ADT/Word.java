public class Word {

    private String word;

    private int count;

    public Word(String word, int count) {
        this.word = word;
        this.count = count;

    }

    public String getWord() {
        return this.word;
    }

    public int getCount() {
        return this.count;
    }

    public void addCount() {
        this.count++;
    }

    public void printData() {
        System.out.println(this.word + " : " + this.count);
    }
}