#include <stdio.h>
#include <math.h>
#include <stdlib.h>

typedef struct wave {
  int index;
  int level;
}wave;

//"-lm" is needed when compiling

// [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
//        |     
//     (Height)     
// 
//     ____LEVELS_____            
//     -1    ->   -0.9
//     -0.9  ->   -0.8
//     -0.8  ->   -0.7
//     -0.7  ->   -0.6
//     -0.6  ->   -0.5
//     -0.5  ->   -0.4
//     -0.4  ->   -0.3
//     -0.3  ->   -0.2
//     -0.2  ->   -0.1
//     -0.1  ->   0
//     0     ->   0.1
//     0.1   ->   0.2
//     0.2   ->   0.3
//     0.3   ->   0.4
//     0.4   ->   0.5
//     0.5   ->   0.6
//     0.6   ->   0.7
//     0.7   ->   0.8
//     0.8   ->   0.9
//     0.9   ->   1               
//
//  - Maybe instead use .2 differentiation
//
//    1 -> 0.75 -> 0.5 -> 0.25 -> 0 -> -0.25 -> -0.5 -> -0.75 -> -1
//
//    8 LEVELS!     
//     _
//    / \     ||      ||      ||
//   /   \   |  |    |  |    |
//               |  |    |  |
//                ||      || 
// 

int getLevel(double value) {
  if(value <= 1.00 && value > 0.75) { return 1; };
  if(value <= 0.75 && value > 0.50) { return 2; };
  if(value <= 0.50 && value > 0.25) { return 3; };
  if(value <= 0.25 && value > 0.00) { return 4; };
  if(value <= 0.00 && value > -0.25) { return 5; };
  if(value <= -0.25 && value > -0.50) { return 6; };
  if(value <= -0.50 && value > -0.75) { return 7; };
  if(value <= -0.75 && value > -1.00) { return 8; };

  //Returns 0 if something went wrong
  return 0;
}

int main() {
  double* array;
  
  
  char screen[8][60];

  int z;
  int x;
  for(z=0; z<8; z++) {
    for(x=0; x<60; x++) {
      screen[z][x] = ' ';
    }
  }                                                

  int numPoints;
  double incAmmount;

  
  printf("Number Points: ");
  scanf("%d", &numPoints);
  
  printf("Increment Ammount: ");
  scanf("%lf", &incAmmount);
  
  system("clear");

  int level[numPoints];
  //level = (int*)malloc(numPoints * sizeof(int));
  array = (double*)malloc(numPoints * sizeof(double));
  double *ptr_array = &array[0];

  double i = 0.00;
  int index = 0;
  for(index=0; index<numPoints; index++) {
    array[index] = i;
    i=i+incAmmount;
  }

  //printWave(&array[0], numPoints);
  
  int j = 0;
  while(j < numPoints) {
    //printf("%f : ", cos(array[j]));
    level[j] = getLevel(cos(array[j]));
    //printf("%d\n", level[j]);
    j++;
  }
  int k;
  for(k=0; k<numPoints; k++) {
    int level_num = (level[k]) - 1;
    screen[level_num][k] = '|';
  }

  char screenCopy[8][60];
  int v;
  int c;

  //Another instance of inital screen
  for(v=0; v<8; v++) {
    for(c=0; c<60; c++) {
      screenCopy[v][c] = screen[v][c];
    }
  }
 
  //Turn over to screenCopy
  for(v=0; v<8; v++) {
    for(c=0; c<numPoints; c++) {
      if(screenCopy[v][c] == '|' && c != 59) {
        int lineHeight = v;
        int vertical = 0;
        int point;
        while(vertical <= 7) {
          if(screenCopy[vertical][c+1] != ' ') {
            break;
          }
          vertical++;
        }
        if(vertical < v) {
          while(vertical < v) {
            screen[vertical][c+1] = '|';
            vertical++;
          }
        }
        else if(vertical > v) {
          while(vertical > v) {
            screen[vertical][c+1] = '|';
            vertical--;
          }
        }
        else {
          break;
        }
        
        
      }
      int startIndex = 1;
      
    }
  }  

//END OF BEATUIFY

  for(v=0; v<8; v++) {
    for(c=0; c<numPoints; c++) {
      printf("%c", screen[v][c]);
    }
    printf("\n");
  }

  double answer = cos((int)numPoints);
  
  printf("\n\n");
  
  free(array);
  //free(level);
   
  //while(1) {
  //  char c;
  //  c = getchar();
  //  printf("%c", c);
  //}
  printf("Function: cos(x)\n");

  return 0;
}
