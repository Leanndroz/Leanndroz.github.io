This code just takes in a text file and then allows the user to move the cursor around
with w, a, s, d.  It will then tell you how similar your drawing is to the text file.
Just a small implementation of how statistics in computer images might work on a 
very basic level.
