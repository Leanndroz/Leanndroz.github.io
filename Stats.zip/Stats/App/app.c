#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    
    FILE* fptr;
    char filecontents_line[1275];
    char filecontents[25][50];

    fptr = fopen("./circle.txt", "r");
    //fgets(&filecontents[0], 1275, fptr);
    char ch;
    int vertical = 0;
    int horizontal = 0;
    do {
        ch = fgetc(fptr);
        if(ch != '\n') {
            filecontents[vertical][horizontal] = ch;
            horizontal++;
        }
        else {
            horizontal = 0;
            vertical++;
        }
        // Checking if character is not EOF.
        // If it is EOF stop reading.
    } while (ch != EOF);
    
    int d;
    

    char matrix[25][50];

    //Extra 25 for the '\n' character
    char screen[1275];
    char* screen_ptr = &screen[0];

    int i;
    int j;
    for(i=0; i<25; i++) {
        for(j=0; j<50; j++) {
            matrix[i][j] = '.';
            //printf("%c", filecontents[i][j]);
        }
        //printf("\n");
    }

    int x = 23;
    int y = 3;
    matrix[y][x] = 'O';

    char test;
    int newX = x;
    int newY = y;
    while (1) {
        system("cls");

        int incorrect = 0;

        int screen_int = 0;
        for(i=0; i<25; i++) {
            for(j=0; j<50; j++) {
                printf("%c", matrix[i][j]);
                //screen[screen_int] = matrix[i][j];
                //screen_int++;
                if(matrix[i][j] != filecontents[i][j]) {
                    incorrect++;
                }
            }
            printf("\n");
            //screen[screen_int] = '\n';
            //screen_int++;
        }
        //printf("%s", screen);

        float percent = (1250.0 - incorrect) / 1250.0;
        printf("%s%d\n", "Incorrect: ", incorrect);
        printf("%s%.6f", "Percent Correct: ", percent*100);

        test = getch();

        int value = (int)test;
        



        if(value == 119) {
            newY = y - 1;
        }
        else if(value == 97) {
            newX = x - 1;
        }
        else if(value == 115) {
            newY = y + 1;
        }
        else if(value == 100) {
            newX = x + 1;
        }

        //matrix[y][x] = '.';
        matrix[newY][newX] = 'O';

        y = newY;
        x = newX;

        if(value == 113) {
            break;
        }
        
    }
    return 0;

}