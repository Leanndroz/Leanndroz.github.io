import java.util.Random;
import java.util.Scanner;
import java.util.HashMap;

public class GeneratePassword {

    public static void main(String args[]) {

        Scanner scnr = new Scanner(System.in);

        System.out.print("Enter the number of blocks(4 character sections): ");
        int input = scnr.nextInt();

        Random rand = new Random();
        String password = "";

        int[] numbers = new int[input * 4];

        for(int i = 0; i < numbers.length; i++) {
            numbers[i] = rand.nextInt(10);
            if(i % 4 == 0 && i != 0) {
                password += "-";
            }
            password += numbers[i];

            //System.out.println(numbers[i]);
        }

        HashMap<Integer, Character> hm = new HashMap<Integer, Character>();
        hm.put(0, 'A');
        hm.put(1, 'B');
        hm.put(2, 'C');
        hm.put(3, 'D');
        hm.put(4, 'E');
        hm.put(5, 'F');
        hm.put(6, 'G');
        hm.put(7, 'H');
        hm.put(8, 'I');
        hm.put(9, 'J');
        hm.put(10, 'K');
        hm.put(11, 'L');
        hm.put(12, 'M');
        hm.put(13, 'N');
        hm.put(14, 'O');
        hm.put(15, 'P');
        hm.put(16, 'Q');
        hm.put(17, 'R');
        hm.put(18, 'S');
        hm.put(19, 'T');
        hm.put(20, 'U');
        hm.put(21, 'V');
        hm.put(22, 'W');
        hm.put(23, 'X');
        hm.put(24, 'Y');
        hm.put(25, 'Z');
        hm.put(26, 'a');
        hm.put(27, 'b');
        hm.put(28, 'c');
        hm.put(29, 'd');
        hm.put(30, 'e');
        hm.put(31, 'f');
        hm.put(32, 'g');
        hm.put(33, 'h');
        hm.put(34, 'i');
        hm.put(35, 'j');
        hm.put(36, 'k');
        hm.put(37, 'l');
        hm.put(38, 'm');
        hm.put(39, 'n');
        hm.put(40, 'o');
        hm.put(41, 'p');
        hm.put(42, 'q');
        hm.put(43, 'r');
        hm.put(44, 's');
        hm.put(45, 't');
        hm.put(46, 'u');
        hm.put(47, 'v');
        hm.put(48, 'w');
        hm.put(49, 'x');
        hm.put(50, 'y');
        hm.put(51, 'z');
        //System.out.println(hm.toString());

        int flip;
        StringBuilder SBpassword = new StringBuilder(password);
        for(int i = 0; i < numbers.length; i++) {
            flip = rand.nextInt(2);
            numbers[i] = rand.nextInt(52);
            if(SBpassword.charAt(i) != '-' && flip == 1) {
                //System.out.println(hm.get(numbers[i]));
                //char c = hm.get(numbers[i]);
                SBpassword.setCharAt(i, hm.get(numbers[i]));
            }
        }
        
        password = SBpassword.toString();
        System.out.println("\nGenerated Password: " + password);
    }
}